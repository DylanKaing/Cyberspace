package com.example.resourceServer;

public class Message {

    private String text;

        public Message(){}

        public String getText(){
            return text;
        }

        public void setText(String text){
            this.text = text;
        }
    
}
