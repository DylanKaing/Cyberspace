# CS 1653 Project: Phase 3 Feedback

__Group:__ Black Myth Cryptographer

__Names:__ Cao, Nick; Kaing, Dylan C; Qian, Xingcheng; Acero, Alex

__Users:__ ruc36; dck34; xiq29; ala452

## Comments

### Documentation and writeup

Please follow the format as specified (e.g., no introduction nor conclusion regarding interplay between different components)

Please include a proper heading.

Nice details in the writeup, very thorough

45 / 50

### Design approval


10 / 10

### Demo and code

Some functionality was not completed by the deadline

30 / 35

### Scheduling demo


5 / 5

### Other notes



## Overall grade

90 / 100

